/* global React */
const { useState, useMemo } = React;

// ───────── tweaks defaults ─────────
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "honey",
  "density": "compact",
  "showCrest": true,
  "stripedRows": false,
  "highlightTickers": true,
  "headlineTreatment": "stars",
  "language": "en"
}/*EDITMODE-END*/;

// ───────── i18n ─────────
const COPY = {
  en: {
    welcome: "All Assets Tracker",
    tagline: "Every asset class on Earth, ranked by market cap.",
    filters: { public: "Public companies", private: "Private companies", crypto: "Crypto", commodities: "Commodities", fiat: "Fiat (M2)", misc: "Misc" },
    cols: { rank: "#", name: "Name", mcap: "Market Cap", price: "Price", c24: "24h", c7d: "7d", c30d: "30d", c1y: "1y" },
    search: "Search the list…  (⌘K)",
    counter: "assets tracked",
    by: "Made by", author: "Casa Araoz",
    totalLabel: "Total market cap", lastUpd: "Last updated",
  },
  es: {
    welcome: "Todos los Activos del Mundo",
    tagline: "Cada clase de activo en la Tierra, rankeada por capitalización. Lectura de Casa Araoz.",
    filters: { public: "Empresas públicas", private: "Empresas privadas", crypto: "Cripto", commodities: "Commodities", fiat: "Fiat (M2)", misc: "Misc" },
    cols: { rank: "#", name: "Nombre", mcap: "Cap. de Mercado", price: "Precio", c24: "24h", c7d: "7d", c30d: "30d", c1y: "1a" },
    search: "Buscar en el índice…  (⌘K)",
    counter: "activos en el índice",
    by: "Hecho por", author: "Casa Araoz",
    totalLabel: "Cap. de mercado total", lastUpd: "Última actualización",
  }
};

// ───────── formatters ─────────
const fmtMcap = (n) => {
  if (n == null) return "—";
  if (n >= 1e12) return "$" + (n / 1e12).toFixed(2) + "T";
  if (n >= 1e9) return "$" + (n / 1e9).toFixed(2) + "B";
  return "$" + (n / 1e6).toFixed(0) + "M";
};
const fmtPrice = (n) => {
  if (n == null) return "—";
  if (n >= 1000) return "$" + n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  return "$" + n.toFixed(2);
};
const fmtPct = (n) => {
  if (n == null) return "—";
  const sign = n > 0 ? "+" : "";
  return sign + n.toFixed(2) + "%";
};

// ───────── theme tokens ─────────
const ACCENTS = {
  honey:  { tint: "#FBE9A6", row: "#FFF7DA", chip: "#F4E29B", text: "#3a2a07" },
  sage:   { tint: "#D6E2C9", row: "#EAF1DF", chip: "#C9D8B6", text: "#1f2e15" },
  ink:    { tint: "#D8DEE9", row: "#E7ECF3", chip: "#C7D0DE", text: "#0e1a2e" },
  brick:  { tint: "#F2D2C2", row: "#F9E5D9", chip: "#EAB89F", text: "#3a1808" },
};

// ───────── tiny crest (footer) ─────────
function CrestMark({ size = 28 }) {
  return (
    <svg width={size} height={size * 1.18} viewBox="0 0 60 70" aria-hidden>
      <defs>
        <pattern id="cr-stripes" width="3" height="3" patternUnits="userSpaceOnUse">
          <path d="M0 3 L3 0" stroke="#1a1a1a" strokeWidth="0.4" />
        </pattern>
      </defs>
      <path d="M5 8 L30 4 L55 8 L55 38 Q55 56 30 66 Q5 56 5 38 Z" fill="url(#cr-stripes)" stroke="#1a1a1a" strokeWidth="1.2" />
      <path d="M30 4 L30 66" stroke="#1a1a1a" strokeWidth="0.6" opacity="0.4" />
      <path d="M5 24 L55 24" stroke="#1a1a1a" strokeWidth="0.6" opacity="0.4" />
      <text x="30" y="22" textAnchor="middle" fontFamily="serif" fontSize="9" fontStyle="italic" fill="#1a1a1a">CA</text>
      <text x="30" y="44" textAnchor="middle" fontFamily="serif" fontSize="14" fill="#1a1a1a">★</text>
    </svg>
  );
}

// ───────── asset glyph (initials disc) ─────────
function AssetGlyph({ a, size = 28 }) {
  const initials = a.name
    .replace(/\([^)]*\)/g, "")
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map(w => w[0])
    .join("")
    .toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: 999,
      background: a.color, color: "#fff",
      display: "grid", placeItems: "center",
      fontFamily: "'Inter', sans-serif", fontWeight: 600,
      fontSize: size * 0.4, letterSpacing: "0.02em",
      boxShadow: "inset 0 -1px 0 rgba(0,0,0,0.15), 0 1px 2px rgba(0,0,0,0.1)",
      flexShrink: 0,
    }}>{initials}</div>
  );
}

// ───────── filter chip ─────────
function FilterChip({ label, count, active, onClick, accent }) {
  return (
    <button onClick={onClick} className="ftr-chip" data-active={active}
      style={{
        "--chip-tint": accent.chip,
        "--chip-text": accent.text,
      }}>
      <span className="ftr-chk" aria-hidden>
        {active ? (
          <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1.5 5 L4 7.5 L8.5 2.5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
        ) : null}
      </span>
      <span className="ftr-label">{label}</span>
      <span className="ftr-count">{count}</span>
    </button>
  );
}

// ───────── ticker tag (with optional highlight) ─────────
function TickerTag({ ticker, type, accent, highlight }) {
  if (!ticker && !type) return null;
  return (
    <span className="tkr-row">
      {ticker ? (
        <span className="tkr" style={highlight ? { background: accent.tint, color: accent.text } : null}>
          {ticker}
        </span>
      ) : null}
      <span className="tkr-type">{type}</span>
    </span>
  );
}

// ───────── PctCell ─────────
function PctCell({ v }) {
  if (v == null) return <span className="muted">—</span>;
  const cls = v > 0 ? "pos" : v < 0 ? "neg" : "muted";
  return <span className={"pct " + cls}>{fmtPct(v)}</span>;
}

// ───────── App ─────────
function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const accent = ACCENTS[tweaks.accent] || ACCENTS.honey;
  const t = COPY[tweaks.language] || COPY.en;

  const [filters, setFilters] = useState({
    PUBLIC: true, PRIVATE: true, CRYPTO: true, COMMODITIES: false, FIAT: false, MISC: true,
  });
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState({ key: "mcap", dir: "desc" });

  const counts = useMemo(() => {
    const c = { PUBLIC: 0, PRIVATE: 0, CRYPTO: 0, COMMODITIES: 0, FIAT: 0, MISC: 0 };
    for (const a of window.ASSETS) c[a.type] = (c[a.type] || 0) + 1;
    return c;
  }, []);

  const rows = useMemo(() => {
    let r = window.ASSETS.filter(a => filters[a.type]);
    if (query) {
      const q = query.toLowerCase();
      r = r.filter(a => a.name.toLowerCase().includes(q) || (a.ticker || "").toLowerCase().includes(q));
    }
    r = [...r].sort((a, b) => {
      const av = a[sort.key], bv = b[sort.key];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      return sort.dir === "desc" ? bv - av : av - bv;
    });
    // re-rank for display
    return r.map((a, i) => ({ ...a, displayRank: i + 1 }));
  }, [filters, query, sort]);

  const totalMcap = useMemo(() => rows.reduce((s, a) => s + (a.mcap || 0), 0), [rows]);

  const toggleSort = (key) => {
    setSort(s => s.key === key ? { key, dir: s.dir === "desc" ? "asc" : "desc" } : { key, dir: "desc" });
  };

  const isComfortable = tweaks.density === "comfortable";

  return (
    <div className="page" style={{ "--accent-tint": accent.tint, "--accent-row": accent.row, "--accent-text": accent.text }}>
      {/* ───── HEADER ───── */}
      <header className="hero">
        <div className="hero-left">
          <span className="hero-crest" aria-hidden><CrestMark size={26} /></span>
          <h1 className="hero-title"><span>{t.welcome}</span></h1>
          <p className="hero-tag">{t.tagline}</p>
        </div>
        <div className="hero-stats">
          <div className="stat">
            <span className="stat-num">1,211</span>
            <span className="stat-lbl">{t.counter}</span>
          </div>
          <span className="stat-sep">·</span>
          <div className="stat">
            <span className="stat-num">{fmtMcap(window.ASSETS.reduce((s, a) => s + (a.mcap || 0), 0))}</span>
            <span className="stat-lbl">{t.totalLabel}</span>
          </div>
          <span className="stat-sep">·</span>
          <div className="stat">
            <span className="stat-num">May 3, 2026</span>
            <span className="stat-lbl">{t.lastUpd}</span>
          </div>
        </div>
      </header>

      {/* ───── SEARCH + FILTERS ───── */}
      <div className="toolbar">
        <div className="search">
          <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden><circle cx="6" cy="6" r="4.2" fill="none" stroke="currentColor" strokeWidth="1.4"/><path d="M9.2 9.2 L12.5 12.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder={t.search}
          />
        </div>

        <div className="chips">
          {[
            ["PUBLIC", t.filters.public],
            ["PRIVATE", t.filters.private],
            ["CRYPTO", t.filters.crypto],
            ["COMMODITIES", t.filters.commodities],
            ["FIAT", t.filters.fiat],
            ["MISC", t.filters.misc],
          ].map(([key, label]) => (
            <FilterChip
              key={key}
              label={label}
              count={counts[key] || 0}
              active={filters[key]}
              onClick={() => setFilters(f => ({ ...f, [key]: !f[key] }))}
              accent={accent}
            />
          ))}
        </div>
      </div>

      {/* ───── TABLE ───── */}
      <main className="card" data-density={tweaks.density} data-striped={tweaks.stripedRows}>
        <div className="table" role="table">
          <div className="thead" role="row">
            <div className="th th-rank">{t.cols.rank}</div>
            <div className="th th-name">{t.cols.name}</div>
            <div className="th th-num sortable" onClick={() => toggleSort("mcap")} data-active={sort.key === "mcap"}>
              {t.cols.mcap} <SortMark on={sort.key === "mcap"} dir={sort.dir} />
            </div>
            <div className="th th-num sortable" onClick={() => toggleSort("price")} data-active={sort.key === "price"}>
              {t.cols.price} <SortMark on={sort.key === "price"} dir={sort.dir} />
            </div>
            <div className="th th-num sortable" onClick={() => toggleSort("c24")} data-active={sort.key === "c24"}>
              {t.cols.c24} <SortMark on={sort.key === "c24"} dir={sort.dir} />
            </div>
            <div className="th th-num sortable" onClick={() => toggleSort("c7d")} data-active={sort.key === "c7d"}>
              {t.cols.c7d} <SortMark on={sort.key === "c7d"} dir={sort.dir} />
            </div>
            <div className="th th-num sortable" onClick={() => toggleSort("c30d")} data-active={sort.key === "c30d"}>
              {t.cols.c30d} <SortMark on={sort.key === "c30d"} dir={sort.dir} />
            </div>
            <div className="th th-num sortable" onClick={() => toggleSort("c1y")} data-active={sort.key === "c1y"}>
              {t.cols.c1y} <SortMark on={sort.key === "c1y"} dir={sort.dir} />
            </div>
          </div>

          {rows.map((a, i) => (
            <div className="trow" role="row" key={a.rank} data-class={a.type}>
              <div className="td td-rank">{a.displayRank}</div>
              <div className="td td-name">
                <AssetGlyph a={a} size={isComfortable ? 30 : 24} />
                <div className="name-stack">
                  <span className="name">{a.name}</span>
                  <TickerTag ticker={a.ticker} type={a.type} accent={accent} highlight={tweaks.highlightTickers} />
                </div>
              </div>
              <div className="td td-num"><strong>{fmtMcap(a.mcap)}</strong></div>
              <div className="td td-num">{fmtPrice(a.price)}</div>
              <div className="td td-num"><PctCell v={a.c24} /></div>
              <div className="td td-num"><PctCell v={a.c7d} /></div>
              <div className="td td-num"><PctCell v={a.c30d} /></div>
              <div className="td td-num"><PctCell v={a.c1y} /></div>
            </div>
          ))}
        </div>
      </main>

      {/* ───── FOOTER (sticky) ───── */}
      <footer className="foot">
        <div className="foot-left">
          <span className="foot-dot" aria-hidden />
          <span className="foot-count">1,211 assets</span>
        </div>
        <div className="foot-right">
          <p>
            <span>{t.by}</span>
            <a href="#" className="author">{t.author}</a>
            {tweaks.showCrest ? <span className="foot-crest" aria-hidden><CrestMark size={14} /></span> : null}
          </p>
        </div>
      </footer>

      {/* ───── TWEAKS ───── */}
      <window.TweaksPanel title="Tweaks" defaultOpen={false}>
        <window.TweakSection title="Theme">
          <window.TweakRadio
            label="Accent"
            value={tweaks.accent}
            options={[
              { value: "honey", label: "Honey" },
              { value: "sage", label: "Sage" },
              { value: "ink", label: "Ink" },
              { value: "brick", label: "Brick" },
            ]}
            onChange={v => setTweak("accent", v)}
          />
          <window.TweakRadio
            label="Density"
            value={tweaks.density}
            options={[
              { value: "compact", label: "Compact" },
              { value: "comfortable", label: "Comfy" },
            ]}
            onChange={v => setTweak("density", v)}
          />
        </window.TweakSection>
        <window.TweakSection title="Table">
          <window.TweakToggle label="Highlight tickers (honey)" value={tweaks.highlightTickers} onChange={v => setTweak("highlightTickers", v)} />
          <window.TweakToggle label="Striped rows" value={tweaks.stripedRows} onChange={v => setTweak("stripedRows", v)} />
        </window.TweakSection>
        <window.TweakSection title="Brand">
          <window.TweakToggle label="Show crest" value={tweaks.showCrest} onChange={v => setTweak("showCrest", v)} />
          <window.TweakRadio
            label="Language"
            value={tweaks.language}
            options={[{ value: "en", label: "EN" }, { value: "es", label: "ES" }]}
            onChange={v => setTweak("language", v)}
          />
        </window.TweakSection>
      </window.TweaksPanel>
    </div>
  );
}

function SortMark({ on, dir }) {
  if (!on) return <span className="sort-mark muted">↕</span>;
  return <span className="sort-mark">{dir === "desc" ? "▾" : "▴"}</span>;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
