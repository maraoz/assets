# Handoff: All Assets Tracker — Casa Araoz Brand Redesign

## Overview
Visual redesign of the **All Assets Tracker** (https://assets.araoz.net) to align with the Casa Araoz brand system. The product is a single-page table that ranks every asset class on Earth (public companies, private companies, crypto, commodities, fiat M2, misc.) by market cap. The redesign keeps the existing functionality and information architecture, but replaces the developer aesthetic with a warm, editorial visual treatment matching the broader Casa Araoz family of products.

## About the Design Files
The files in this bundle (`All Assets Tracker.html`, `app.jsx`, `data.jsx`, `tweaks-panel.jsx`) are **design references implemented in HTML/React for prototyping**. They are not production code to ship as-is.

Your task is to **recreate this design inside the existing All Assets Tracker codebase**, using whatever framework/component library it already uses. Lift the visual tokens, layout, and component structure documented below — don't copy the prototype's `<script type="text/babel">` setup, `window.ASSETS` mock data, or the Tweaks panel into production.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and row class-tints are all final. Recreate pixel-perfectly.

## Screens / Views

There is one screen: the asset list.

### Layout (top → bottom)

1. **Sticky header strip** (~50px tall, full width, bottom-bordered)
   - Left cluster: family crest (24×28px SVG) · "All Assets Tracker" (20px / 600 / -0.015em letter-spacing) · tagline "Every asset class on Earth, ranked by market cap." (12.5px, muted)
   - Right cluster: three baseline-aligned stat pairs separated by middle-dots: `1,211 assets tracked · $TT total market cap · May 3, 2026 last updated`. Numbers 13px/600 ink; labels 10px uppercase letter-spacing 0.12em mute.

2. **Toolbar** (centered column, ~60px gap from header)
   - Search input: 520px max, parchment-card background, 10px radius, search-icon prefix, placeholder "Search the list…  (⌘K)". No `<kbd>` hint on the right.
   - Below: filter chips row (centered, 8px gap, wraps). Each chip: pill-shaped, 1px rule border, 10/14px padding, 13px/500 label, 14px square checkbox on the left, count badge on the right. Active chip: filled with the accent tint (default honey `#F4E29B`), border transparent, dark-ink check filled in, count badge white@55%.
   - Default-active chips: Public, Private, Crypto, Misc. Default-inactive: Commodities, Fiat (M2).

3. **Table card** (max-width 1180px, 14px radius, 1px rule, soft 24px shadow)
   - Header row (sticky, 42px tall, parchment-2 background): columns `# · Name · Market Cap · Price · 24h · 7d · 30d · 1y`. Number columns are right-aligned and click-to-sort. Active sort column is dark ink with ▾/▴ glyph; inactive show muted ↕.
   - Grid: `56px minmax(280px,1fr) 130px 110px 80px 80px 80px 80px`
   - Row height: 42px (compact) or 56px (comfy). Compact is the default.
   - Each row has a `data-class` attribute used for **subtle class tinting**:
     - PUBLIC → white (default card surface)
     - COMMODITIES → `#fbf3df`
     - FIAT → `#eaf3e6`
     - CRYPTO → `#f1ecfb`
     - PRIVATE → `#fbecec`
     - MISC → `#f3eee5`
   - Hover state on any row: warm honey row tint `#FFF7DA` (overrides class tint via `!important`).
   - Name cell: 24px colored disc with white initials (use the asset's brand color), then a stack of `Asset Name` (14px/600) above a row of `TICKER` (mono, honey-highlighted background `#FBE9A6` / dark text `#3a2a07`) + `TYPE LABEL` (uppercase, 9.5px/600, mute).
   - Numeric cells: tabular-nums sans 14px. Market cap is bold. % cells: green `#1a7a3e` for positive, brick-red `#b7300d` for negative, mute em-dash for null.

4. **Sticky footer** (32px tall, fixed to bottom of viewport, parchment-2 background, top-rule, blur-backdrop)
   - Left: 8px green pulse dot `#22a861` with 3px shadow ring + "1,211 assets" (12px tabular).
   - Right: "Made by Casa Araoz [crest]". Crest sits to the right of the link.

## Interactions & Behavior

- **Filter chips** toggle their type on/off in the displayed list. The header counter ("1,211 assets tracked") and the footer counter ("1,211 assets") are **constant** — they reflect total assets, not filtered count. Do NOT make these counters reactive.
- **Sortable columns**: clicking a header cell toggles desc → asc. Default sort: market cap descending. Null values always sort to the bottom.
- **Search** filters by name OR ticker (case-insensitive substring).
- **Hover on row**: full-row honey tint, cursor: pointer. (Click target / dossier behavior is out of scope for this handoff — keep the hover affordance but no required onClick.)
- **Responsive**: below 880px, hide the 7d/30d/1y columns and tighten the grid.

## State Management

- `filters: { PUBLIC, PRIVATE, CRYPTO, COMMODITIES, FIAT, MISC }` booleans
- `query: string` (search text)
- `sort: { key, dir }` where key ∈ {mcap, price, c24, c7d, c30d, c1y} and dir ∈ {asc, desc}
- Asset list comes from your existing data source — the `data.jsx` in this bundle is mock data only.

## Design Tokens

```css
/* Surfaces */
--bg:           #f4f0e8;  /* warm parchment page background */
--bg-2:         #ece7dc;  /* slightly deeper parchment (sticky bars) */
--card:         #fdfcf8;  /* near-white card surface, warmer than #fff */
--card-2:       #faf7ee;  /* table header background */

/* Ink */
--ink:          #1a1a1a;
--ink-2:        #2a2a2a;
--ink-3:        #5a5a5a;
--ink-mute:     #8a8378;

/* Rules */
--rule:         #d9d2c4;  /* hairline */
--rule-soft:    #e6dfd0;  /* row separator */

/* Semantic */
--pos:          #1a7a3e;  /* positive %  */
--neg:          #b7300d;  /* negative %  */
--live-dot:     #22a861;  /* footer pulse */

/* Honey accent (default) */
--accent-tint:  #FBE9A6;  /* ticker pill background */
--accent-row:   #FFF7DA;  /* row hover */
--accent-chip:  #F4E29B;  /* active filter chip */
--accent-text:  #3a2a07;

/* Class tints (row backgrounds) */
--row-public:        transparent;
--row-commodities:   #fbf3df;
--row-fiat:          #eaf3e6;
--row-crypto:        #f1ecfb;
--row-private:       #fbecec;
--row-misc:          #f3eee5;

/* Type */
--font-sans: "IBM Plex Sans", -apple-system, BlinkMacSystemFont, sans-serif;
--font-mono: "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, monospace;
/* Serif is loaded but unused in production (legacy tweak) — feel free to drop */

/* Radii */
--radius-card:   14px;
--radius-input:  10px;
--radius-pill:   999px;
--radius-chip:   3px;     /* ticker tag */

/* Type scale */
title:    20px / 600 / -0.015em
stat-num: 13px / 600
stat-lbl: 10px uppercase / 0.12em
chip:     13px / 500
row-name: 14px / 600 (compact) · 15px / 600 (comfy)
ticker:   10.5px mono / 500 / 0.02em
type-lbl: 9.5px sans / 600 / 0.12em uppercase
num-cell: 14px sans tabular-nums

/* Spacing */
page padding:        24px 28px 64px (bottom reserves space for fixed footer)
header strip pad:    4px 0 14px (with 1px bottom rule)
row height compact:  42px
row height comfy:    56px
table header height: 42px
fixed footer height: ~32px (8px vertical pad)

/* Shadows */
card:   0 1px 0 rgba(255,255,255,0.6) inset, 0 1px 2px rgba(0,0,0,0.03), 0 24px 60px -32px rgba(40,30,10,0.18)
search: 0 1px 0 rgba(0,0,0,0.02), 0 4px 14px -8px rgba(0,0,0,0.08)
search-focus: 0 1px 0 rgba(0,0,0,0.02), 0 6px 18px -8px rgba(0,0,0,0.18)
green-dot-ring: 0 0 0 3px rgba(34,168,97,0.18)
```

### Optional accent palettes (for future theming)
The prototype exposes Honey (default), Sage, Ink, Brick — not required for v1, but the token structure supports it. If you want to keep theme-ability, parameterize `--accent-tint / --accent-row / --accent-chip / --accent-text`.

## Assets

- **Family crest**: small SVG defined inline in `app.jsx` → `CrestMark` component. Diagonal-stripe pattern fill, "CA" italic monogram top half, ★ bottom half, shield silhouette. Use **at two sizes**: 26px (header) and 14px (footer).
- **Asset glyphs**: colored disc with 1–2 letter initials. The brand color comes from the asset record (`a.color`). If your real data doesn't have brand colors, derive a stable color from the ticker hash, or fall back to logo files.
- **Search icon**: inline SVG (14×14, 1.4 stroke). Trivial to replace with whatever icon set the codebase uses.
- **Sort glyphs**: text characters `▾` / `▴` / `↕`. Replace with icon-set equivalents if preferred.

## Files in this bundle

- `All Assets Tracker.html` — full prototype shell with all CSS tokens. **Read the `<style>` block first** — it's the canonical source for spacing, type, and color values.
- `app.jsx` — React component tree showing structure: `App` → `Header` + `Toolbar` + `Card[Table]` + `Footer`. Subcomponents: `FilterChip`, `AssetGlyph`, `TickerTag`, `PctCell`, `CrestMark`, `SortMark`.
- `data.jsx` — mock asset data showing the expected record shape: `{ rank, name, ticker, type, mcap, price, c24, c7d, c30d, c1y, color }`.
- `tweaks-panel.jsx` — prototype-only theme switcher. **Do not port** to production.

## Notes for the implementer

- The numbers `1,211 assets` shown in the header and footer are placeholders — wire to the real total asset count.
- Date "May 3, 2026" is placeholder — wire to the real last-updated timestamp.
- The Tweaks panel (accent / density / language / crest toggle) is design-tooling only. It's safe to drop the entire `<TweaksPanel>` block and the `useTweaks` hook from production.
- The `tagline` and `counter` strings are i18n-ready in the prototype (en/es). Hook into your existing i18n system if applicable; copies are in `app.jsx` → `COPY` const.
- Class tints are subtle on purpose — bump saturation a touch if they're invisible at production rendering, but resist going louder than the values above.
